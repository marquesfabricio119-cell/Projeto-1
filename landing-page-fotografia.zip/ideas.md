# Ideias de Design - Landing Page Fotografia Profissional

## Design Escolhido: Modern Aspirational (Moderno Aspiracional)

### Design Movement
**Modern Aspirational** - Uma abordagem que combina minimalismo moderno com elementos inspiracionais. Usa espaço negativo estratégico, tipografia ousada e cores vibrantes para criar uma sensação de crescimento e transformação.

### Core Principles
1. **Transformação Visual**: Cada seção comunica progresso e evolução através de design progressivo
2. **Hierarquia Clara**: Tipografia em escala e peso definem prioridades sem necessidade de muitos elementos
3. **Espaço Respirável**: Amplo espaço negativo entre seções para evitar sensação de poluição visual
4. **Autenticidade**: Imagens reais de pessoas, não ícones genéricos - humaniza a experiência

### Color Philosophy
- **Primária (Confiança)**: Azul profundo #1E3A8A - representa expertise e profissionalismo
- **Secundária (Ação)**: Verde vibrante #10B981 - representa crescimento e oportunidade
- **Acentos (Urgência)**: Laranja suave #F97316 - cria senso de oportunidade sem agressividade
- **Fundo**: Branco puro com seções em tons de cinza muito claro (#F9FAFB) para criar ritmo
- **Texto**: Cinza escuro #1F2937 para legibilidade máxima

### Layout Paradigm
- **Hero Section**: Imagem full-width à direita com texto à esquerda (assimétrico)
- **Seções Alternadas**: Conteúdo alterna entre esquerda/direita para criar movimento visual
- **Grid 2 Colunas**: Pain points em grid 2x3 com espaçamento generoso
- **Seções com Fundo Colorido**: Algumas seções com fundo azul claro (#EFF6FF) para quebrar monotonia

### Signature Elements
1. **Dividers SVG**: Ondas suaves separando seções, criando fluxo visual
2. **Checkmarks Animados**: Ícones de check em verde que aparecem com animação ao scroll
3. **Pulse Effect nos CTAs**: Botões principais com efeito pulse sutil para atrair atenção

### Interaction Philosophy
- **Fade-in ao Scroll**: Elementos aparecem suavemente conforme o usuário scroll
- **Hover Effects Suaves**: Botões crescem levemente, sombras aumentam
- **Transições de 0.3s**: Todas as animações mantêm ritmo consistente
- **Mobile-First**: Tudo funciona perfeitamente em mobile sem perder elegância

### Animation
- Fade-in com delay progressivo para listas de benefícios
- Slide-in suave para cards de pain points
- Scale-up no hover de botões (1.05x)
- Pulse effect sutil nos CTAs principais (opacidade 0.7 → 1.0)
- Slide-up suave ao scroll para seções inteiras

### Typography System
- **Headlines**: Poppins Bold 700-800 - moderno, geométrico, impactante
- **Subheadlines**: Poppins SemiBold 600 - mantém consistência com peso reduzido
- **Body**: Inter Regular 400 - altamente legível, neutro
- **Pequeno**: Inter Regular 400 com tamanho reduzido para descrições

**Hierarquia de Tamanhos**:
- H1 (Hero): 48px desktop, 32px mobile
- H2 (Seções): 36px desktop, 24px mobile
- H3 (Subseções): 24px desktop, 18px mobile
- Body: 16px desktop, 14px mobile
- Small: 14px desktop, 12px mobile

### Design Decisions
- Sem muitos elementos decorativos - deixar as imagens e conteúdo falarem
- Botões com padding generoso (16px vertical, 32px horizontal)
- Border radius consistente: 8px para cards, 12px para botões
- Sombras suaves: `0 4px 6px rgba(0,0,0,0.07)`
- Espaçamento vertical entre seções: 80px desktop, 60px mobile
